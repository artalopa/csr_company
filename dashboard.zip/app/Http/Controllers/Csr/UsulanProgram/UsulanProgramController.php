<?php

namespace App\Http\Controllers\Csr\UsulanProgram;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class UsulanProgramController extends Controller
{
    public function index()
    {
        return view('csr.usulan_program.index');
    }

    public function create_usulan_opd()
    {
        return view('csr.usulan_program.create_usulan_opd');
    }

    public function create_usulan_perusahaan()
    {
        return view('csr.usulan_program.create_usulan_perusahaan');
    }
}
