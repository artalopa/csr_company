<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
    <meta name="author" content="ASTROCLOUD">
    <meta name="description" content="SIMONCER APPLICATION - DASHBOARD">
    <title>Leadership Dashboard - <?php echo $__env->yieldContent('title'); ?></title>
    <!-- Logo icon -->
    <link rel="icon" href="<?php echo e(asset('assets/static/logo/icon-base.png')); ?>">

    <!-- CSS files -->
    <link href="<?php echo e(asset('assets/dist/css/tabler.min.css')); ?>" rel="stylesheet"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dist/css/custome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dist/css/bar_menu.css')); ?>">

    <!-- Fontawesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <?php echo $__env->yieldContent('css'); ?>

  </head>
  <body>
    <div class="page">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="page-wrapper">
            <div class="container-fluid">
                <div class="page-body">
                    <div class="row">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <!-- Tabler Core -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha384-tsQFqpEReu7ZLhBV2VZlAu7zcOV+rXbYlF2cqB8txI/8aZajjp4Bqd+V6D5IgvKT" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('assets/dist/js/tabler.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('assets/dist/js/sidebar.js')); ?>"></script>

    <?php echo $__env->yieldContent('js'); ?>
  </body>
</html>
<?php /**PATH C:\laragon\www\project\csr\dashboard\resources\views/layouts/general.blade.php ENDPATH**/ ?>