<div class="col-md-12 mb-3">
    <div class="nav-menu">
        <ul class="nav-menu-bar">
            <li class="nav-menu-item">
                <a href="<?php echo e(route('company.create')); ?>" class="nav-menu-link <?php if(Request::routeIs('company.create')): ?> active <?php endif; ?>">
                    <span>
                        <img src="<?php echo e(asset('assets/icon/company/create_company.png')); ?>" alt="" class="nav-menu-icon">
                    </span>
                    <span>Tambah Perusahaan</span>
                </a>
            </li>
            <li class="nav-menu-item">
                <a href="<?php echo e(route('company.index')); ?>" class="nav-menu-link <?php if(Request::routeIs('company.index')): ?> active <?php endif; ?>">
                    <span>
                        <img src="<?php echo e(asset('assets/icon/company/company.png')); ?>" alt="" class="nav-menu-icon">
                    </span>
                    <span>Data Perusahaan</span>
                </a>
            </li>
        </ul>
        <div class="nav-menu-home text-center">
            <a href="">
                <span class="nav-menu-home-icon">
                    <i class="fa-solid fa-house"></i>
                </span>
                <span>
                    <small>Home</small>
                </span>
            </a>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\project\csr\dashboard\resources\views/company/bar_menu.blade.php ENDPATH**/ ?>