<?php $__env->startSection('title', 'SIMONCER'); ?>

<?php $__env->startSection('css'); ?>
<!-- Maps CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/dist/libs/leaflet/leaflet.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/dist/js/maps/style.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Title -->

<!-- Title end -->

<!-- Maps -->
<div class="col-md-12 mb-3">
    <div class="card card-shadow">
        <div class="card-body">
            <div id="map">
                <div class="map-title">
                    <h1>PETA LOKASI PELAKSANAAN CSR</h1>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Maps end -->

<!-- Chart left -->
<div class="col-md-5 mb-3">
    <div class="row g-0 row-deck">
        <div class="col-md-6 mb-3">
            <div class="card card-shadow me-3">
                <div class="card-body">
                    <div id="prioritas" style="height:180px;"></div>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-3">
            <div class="card card-shadow">
                <div class="card-body">
                    <div id="penunjang" style="height:180px;"></div>
                </div>
            </div>
        </div>
        <div class="col-md-12 mb-3">
            <div class="card card-shadow">
                <div class="card-body">
                    <div id="sector" style="height: 377px;"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Chart left end -->

<!-- Chart right -->
<div class="col-md-7 mb-3">
    <div class="row">
        <div class="col-md-12 mb-3">
            <div class="card card-shadow">
                <div class="card-body">
                    <div class="d-flex">
                        <h3 class="card-title fw-bolder">GRAFIK PROGRAM</h3>
                      </div>
                      <div class="row">
                        <div class="col">
                          <div id="program_trafic"></div>
                        </div>
                        <div class="col-md-auto">
                          <div class="divide-y divide-y-fill divide-y__custome">
                            <div class="px-3">
                                <div class="text-muted">
                                  <span class="status-dot" style="background-color: #b2d037;"></span> Terlaksana
                                </div>
                                <div class="h3">6,458</div>
                            </div>
                            <div class="px-3">
                              <div class="text-muted">
                                <span class="status-dot" style="background-color: #00adad;"></span> Belum Terlaksana
                              </div>
                              <div class="h3">11,425</div>
                            </div>
                            <div class="px-3">
                              <div class="text-muted">
                                <span class="status-dot" style="background-color: #4e4c8c"></span> Melebihi Jadwal
                              </div>
                              <div class="h3">6,458</div>
                            </div>
                            <div class="px-3">
                              <div class="text-muted">
                                <span class="status-dot" style="background-color: #f2591f"></span> Tidak Terlaksana
                              </div>
                              <div class="h3">3,985</div>
                            </div>
                          </div>
                        </div>
                      </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 mb-3">
            <div class="row row-deck">
                <div class="col-md-6 mb-3">
                    <div class="card card-shadow">
                        <div class="card-body">
                            <div id="program_unggulan"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-3">
                    <div class="card card-shadow">
                        <div class="card-body">
                            <div id="program_reguler"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Chart right end-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- Maps script -->
<script src="<?php echo e(asset('assets/dist/libs/leaflet/leaflet.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dist/js/maps/maps.js')); ?>"></script>

<!-- Speedometer chart script -->
<script src="<?php echo e(asset('assets/dist/js/echarts/js/echarts-all.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dist/js/echarts/program_prioritas.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dist/js/echarts/program_penunjang.js')); ?>"></script>

<!-- Apexcharts js -->
<script src="<?php echo e(asset('assets/dist/libs/apexcharts/dist/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dist/js/apexcharts/sector.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dist/js/apexcharts/program_chart.js')); ?>"></script>

<!-- Donut chart js -->
<script src="<?php echo e(asset('assets/dist/js/donutchart/unggulan.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dist/js/donutchart/regular.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\project\csr\dashboard\resources\views/dashboard.blade.php ENDPATH**/ ?>