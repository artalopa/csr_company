<footer class="footer footer-transparent bg-green__custome d-print-none">
    <div class="container-xl">
        <div class="row text-center align-items-center justify-content-center">
            <div class="col-12 col-lg-auto mt-3 mt-lg-0">
                <ul class="list-inline list-inline-dots mb-0">
                    <li class="list-inline-item">
                        <span class="fs-3">simoncer © 2023</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>
